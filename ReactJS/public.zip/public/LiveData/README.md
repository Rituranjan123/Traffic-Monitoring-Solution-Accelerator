# Python-Javascript-websocket-video-streaming-
Python javascipt websocket video streaming without flask

streaming webcam video directly into html webpage using javascipt websockets using opencv
